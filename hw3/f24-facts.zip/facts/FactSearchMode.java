package facts;

public interface FactSearchMode {
	int AUTHOR_VAL = 0;
	int TEXT_VAL   = 1;
	int TYPE_VAL   = 2;
	int ALL_VAL    = 3;

}
